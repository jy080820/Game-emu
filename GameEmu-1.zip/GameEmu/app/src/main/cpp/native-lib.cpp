#include <jni.h>
#include <string>
#include <android/native_window_jni.h>
#include <android/log.h>

#define LOG_TAG "EmulatorCore_C"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

ANativeWindow* gameWindow = nullptr;

extern "C" JNIEXPORT void JNICALL
Java_com_example_gameemu_EmulatorCore_initExeEngine(JNIEnv* env, jobject, jstring path, jobject surface) {
    const char *filePath = env->GetStringUTFChars(path, nullptr);

    // 1. 안드로이드 SurfaceView를 C++ Native Window로 변환
    if (surface != nullptr) {
        gameWindow = ANativeWindow_fromSurface(env, surface);
        LOGI("Native Window linked. Ready to render EXE graphics.");
    }

    // TODO: 여기에 Box86 / Wine 초기화 및 filePath(EXE) 실행 코드 연동
    // 예: wine_main(filePath, gameWindow);

    LOGI("EXE Game Started: %s", filePath);
    env->ReleaseStringUTFChars(path, filePath);
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_gameemu_EmulatorCore_sendTouchInput(JNIEnv* env, jobject, jint action, jfloat x, jfloat y) {
    // 터치스크린 입력을 EXE 게임의 마우스/키보드 이벤트로 변환하여 전달
    // action: 0 (DOWN), 1 (UP), 2 (MOVE)
    LOGI("Touch Input Received: Action=%d, X=%f, Y=%f", action, x, y);

    // TODO: Wine의 DirectInput 또는 X11 마우스 이벤트로 x, y 좌표 주입
}
