package com.example.gameemu

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 전체 화면 (Status bar, Navigation bar 숨김)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        // 하드코딩된 테스트 파일 경로 (실제 프로덕션에서는 FilePicker(SAF) 인텐트 사용)
        // val testFilePath = "/storage/emulated/0/Download/game.html"
        val testFilePath = "/storage/emulated/0/Download/game.exe"

        setContent {
            GameScreen(filePath = testFilePath)
        }
    }
}

@Composable
fun GameScreen(filePath: String) {
    val isHtml = filePath.endsWith(".html", ignoreCase = true)
    val isExe = filePath.endsWith(".exe", ignoreCase = true)

    // Box를 사용하면 뷰(게임화면) 위에 또 다른 뷰(가상 터치패드)를 Z축으로 겹칠 수 있습니다.
    Box(modifier = Modifier.fillMaxSize()) {

        // 1. 백그라운드 게임 렌더링 계층
        when {
            isHtml -> HtmlGameScreen(filePath = filePath, modifier = Modifier.fillMaxSize())
            isExe -> ExeGameScreen(filePath = filePath, modifier = Modifier.fillMaxSize())
            else -> { /* 포맷 에러 처리 UI */ }
        }

        // 2. 포그라운드 터치 컨트롤러 오버레이 계층
        // HTML은 자체적으로 터치가 가능하므로, EXE 구동 시 혹은 옵션 켤 때만 보이게 설정 가능
        TouchControllerOverlay(isExe = isExe)
    }
}
