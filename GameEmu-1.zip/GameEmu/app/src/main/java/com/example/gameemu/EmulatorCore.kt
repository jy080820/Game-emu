package com.example.gameemu

import android.view.Surface

object EmulatorCore {
    init {
        System.loadLibrary("gameemu")
    }

    // C++로 EXE 파일 경로와 화면에 그릴 Surface 전달
    external fun initExeEngine(filePath: String, surface: Surface)

    // 가상 터치패드의 입력을 C++로 전달
    external fun sendTouchInput(action: Int, x: Float, y: Float)
}
