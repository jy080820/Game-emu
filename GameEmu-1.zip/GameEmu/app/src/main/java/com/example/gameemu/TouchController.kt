package com.example.gameemu

import android.view.MotionEvent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInteropFilter
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun TouchControllerOverlay(isExe: Boolean) {
    // 터치 입력 핸들러 (C++로 전송)
    val onTouch = { action: Int, x: Float, y: Float ->
        if (isExe) EmulatorCore.sendTouchInput(action, x, y)
    }

    Box(modifier = Modifier.fillMaxSize()) {
        // 좌측 방향키 (D-Pad) 영역
        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            TouchButton("W", onTouch, 0f, -1f) // Up
            Row {
                TouchButton("A", onTouch, -1f, 0f) // Left
                Spacer(modifier = Modifier.width(48.dp))
                TouchButton("D", onTouch, 1f, 0f)  // Right
            }
            TouchButton("S", onTouch, 0f, 1f)  // Down
        }

        // 우측 액션 버튼 (클릭, 스페이스 등) 영역
        Row(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(32.dp)
        ) {
            TouchButton("L-Click", onTouch, 99f, 99f) // 임의의 코드로 마우스 좌클릭 매핑
            Spacer(modifier = Modifier.width(16.dp))
            TouchButton("R-Click", onTouch, 100f, 100f) // 마우스 우클릭 매핑
        }
    }
}

@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun TouchButton(label: String, onTouchAction: (Int, Float, Float) -> Unit, mappedX: Float, mappedY: Float) {
    Box(
        modifier = Modifier
            .size(70.dp)
            .background(Color.White.copy(alpha = 0.3f), CircleShape)
            .pointerInteropFilter { motionEvent ->
                when (motionEvent.action) {
                    MotionEvent.ACTION_DOWN -> onTouchAction(0, mappedX, mappedY)
                    MotionEvent.ACTION_UP -> onTouchAction(1, mappedX, mappedY)
                }
                true
            },
        contentAlignment = Alignment.Center
    ) {
        Text(text = label, color = Color.White, fontSize = 16.sp)
    }
}
