# GameEmu (HTML/EXE 게임 에뮬레이터 뼈대)

## 여는 방법
1. Android Studio 실행 → **Open** → 압축을 푼 `GameEmu` 폴더 선택
2. Gradle 동기화가 끝날 때까지 대기 (NDK, CMake가 자동 설치될 수 있음)
3. 실행하면 전체화면 가로모드로 켜지고, 하단 좌/우측에 반투명 가상 조이패드가 표시됨

## 구조
- `MainActivity.kt` — 앱 진입점, 전체화면 처리, HTML/EXE 분기
- `HtmlEngine.kt` — WebView 기반 HTML5 게임 구동
- `ExeEngine.kt` — SurfaceView + JNI로 EXE 렌더링 화면 연결
- `EmulatorCore.kt` — Kotlin ↔ C++ JNI 브릿지
- `TouchController.kt` — 가상 D-Pad/버튼 오버레이 UI
- `cpp/native-lib.cpp` — Surface 연결, 터치 입력 수신부 (여기에 실제 엔진 연동 필요)

## 중요 — 여기서 끝나는 부분
`native-lib.cpp`의 `initExeEngine()`과 `sendTouchInput()`은 **뼈대(스텁)**입니다.
실제로 EXE(윈도우용 실행 파일)를 안드로이드에서 구동하려면 Wine을 안드로이드용으로 포팅한
바이너리(x86 명령어를 ARM으로 변환하는 Box86/Box64 등 포함)를 직접 빌드해서 연결해야 하며,
이는 수 GB 규모의 대형 오픈소스 엔진을 통째로 이식하는 작업입니다.
이 저장소만으로는 EXE 파일이 실제로 화면에 그려지지 않으며, TODO로 표시된 지점에
해당 엔진의 API를 연동해야 동작합니다. (예: 오픈소스 Winlator 프로젝트가 이 작업을 실제로 해낸 사례입니다.)

HTML5 게임 쪽은 WebView만으로 즉시 동작합니다.

## 파일 접근 관련
- Android 11+ (API 30+)에서는 `READ_EXTERNAL_STORAGE`만으로 임의 경로 접근이 제한될 수 있어,
  실제 배포판에서는 SAF(Storage Access Framework)의 파일 선택 인텐트로 교체하는 것을 권장합니다.
